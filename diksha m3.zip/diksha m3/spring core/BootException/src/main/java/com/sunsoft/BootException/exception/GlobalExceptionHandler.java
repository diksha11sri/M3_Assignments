package com.sunsoft.BootException.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler({InvalidProductIdException.class,InvalidProductNameException.class})
	public ResponseEntity<String> handleExceptions(Exception ex)
	{
		if(ex instanceof InvalidProductIdException)
		{
			HttpStatus status=HttpStatus.NOT_FOUND;
			return new ResponseEntity(" inavalid product id",status);
			
		}
		else if(ex instanceof InvalidProductNameException)
		{
			HttpStatus status=HttpStatus.NOT_FOUND;
			return new ResponseEntity(" invalid product name",status);
		}
		else
			return null;
	}
	}

