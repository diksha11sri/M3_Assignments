package com.sunsoft.BootException.exception;

public class InvalidProductNameException extends Exception {

	public InvalidProductNameException(String str)
	{
		super(str);
	}

}
