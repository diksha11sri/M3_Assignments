package com.sunsoft.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sunsoft.repository.ITraineeRepository;
import com.sunsoft.Entity.Trainee;
@Service
public class TraineeServiceImpl  implements ITraineeService{
@Autowired
private ITraineeRepository  traineeRepository;
	@Override
	@Transactional
	public List<Trainee> getTrainee() {
		
		return traineeRepository.findAll();
	}

	@Override
	@Transactional
	public void saveTrainee(Trainee theTrainee) {
		traineeRepository.save(theTrainee);
		
	}

	@Override
	@Transactional
	public Optional<Trainee> getTrainee(int id) {
		Optional<Trainee> traineeObj=traineeRepository.findById(id);
		
		return traineeObj;
	}

	@Override
	public void deleteTrainee(int theId) {
		 traineeRepository.deleteById(theId);
		
	}

}