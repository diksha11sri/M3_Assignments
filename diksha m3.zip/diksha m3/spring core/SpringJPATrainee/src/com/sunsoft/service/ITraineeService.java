package com.sunsoft.service;

import java.util.List;
import java.util.Optional;

import com.sunsoft.Entity.Trainee;

public interface ITraineeService {
	public List<Trainee> getTrainee();
	public void saveTrainee(Trainee theTrainee);
	public Optional<Trainee> getTrainee(int theId);
	public void deleteTrainee(int theId);
}