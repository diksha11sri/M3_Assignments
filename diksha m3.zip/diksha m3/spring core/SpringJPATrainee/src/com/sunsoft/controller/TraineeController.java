package com.sunsoft.controller;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import org.springframework.web.servlet.ModelAndView;

import com.sunsoft.service.ITraineeService;

///Employee/list
import com.sunsoft.Entity.Trainee;

@Controller
@RequestMapping("/Trainee")
public class TraineeController {
	private static final Logger LOG =LoggerFactory.getLogger(TraineeController.class);
	
	@Autowired
	private ITraineeService traineeService;
	
	@GetMapping("/list")
	public String listCustomers(Model theModel) {
		List<Trainee> theTrainee=traineeService.getTrainee();
		theModel.addAttribute("trainees", theTrainee);
		
		System.out.println("List of data "+theTrainee);
		
		return "list-Trainee";
	}
	
	
	@GetMapping("/SpringJPATrainee/Trainee/mainPage")
	public String helloWorld(HttpServletRequest request,HttpServletResponse res)
	{
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		
		if(password.equals("admin"))
				{
			
			return "mainpage";
			
				}
		else
		{
			return  "Invalid user credentials";
		}}
	
@GetMapping("/showForm")
public String showFormForAdd(Model theModel)
{
	LOG.debug("inside show customer-form handler method");
	Trainee theTrainee=new Trainee();
	theModel.addAttribute("trainee",theTrainee);
	return "Trainee-form";
		
		
		
}
@GetMapping("/mainPage")
public String showMainPage(Model theModel)
{
	LOG.debug("inside show customer-form handler method");
	
	return "mainpage";
		
		
		
}

@PostMapping("/saveTrainee")
public String saveCustomer(@ModelAttribute("trainee")Trainee theTrainee)
{
	System.out.println("Save data Employee"+theTrainee);
	traineeService.saveTrainee(theTrainee);
return "redirect:/Trainee/list";
	
}

@GetMapping("/updateForm")
public String showFormForUpdate(@RequestParam("traineeId")int theId,Model theModel)
{
	Optional<Trainee> theTrainee=traineeService.getTrainee(theId);
	theModel.addAttribute("trainee",theTrainee);
	return "Trainee-form";
}
@GetMapping("/delete")
public String deleteCustomer(@RequestParam("traineeId")int theId)
{
	traineeService.deleteTrainee(theId);
	return "redirect:/Trainee/list";
	
}
@GetMapping("/find")
public String finfForm()
{
	return "find";
}
@PostMapping("retrieveForm")
public String retrieveCustomer(HttpServletRequest req,Model theModel)
{
	int theId=Integer.parseInt(req.getParameter("id"));
	Optional<Trainee> trainee=traineeService.getTrainee(theId);
	if(trainee.isPresent()){
		theModel.addAttribute("trainee", trainee.get());
	}
	return "displayOneTrainee";
	}
	
}

