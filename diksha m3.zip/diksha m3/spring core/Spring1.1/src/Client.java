import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		


		
				ApplicationContext context=new ClassPathXmlApplicationContext("helloBean.xml");


				Employee obj=(Employee) context.getBean("hello");
				System.out.println("printing details of employee");

				System.out.println("employee id:"+obj.getId());
				System.out.println("employee name:"+obj.getName());
				System.out.println("employee salary:"+obj.getSalary());
				System.out.println("employee business unit:"+obj.getBu());
				System.out.println("emplyee age:"+obj.getAge());
					


		}

}
