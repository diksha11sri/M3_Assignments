package com.capge.AuthorBook.Controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capge.AuthorBook.Entity.Author;

public class Test3 {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JpaAssign2");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		Query query = entityManager.createQuery("select a from Author a where a.name='Diksha'");
		
		Author a = (Author)query.getSingleResult();
		
		System.out.println(a);

	}

}
