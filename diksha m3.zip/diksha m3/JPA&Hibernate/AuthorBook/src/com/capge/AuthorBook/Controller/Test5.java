package com.capge.AuthorBook.Controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capge.AuthorBook.Entity.Author;

public class Test5 {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JpaAssign2");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		System.out.println("Diksha");

		Query query = entityManager.createQuery("select a.name from Book a where a.isbn='456T'");
		
		String a = (String)query.getSingleResult();
		
		System.out.println(a);

	}

}
