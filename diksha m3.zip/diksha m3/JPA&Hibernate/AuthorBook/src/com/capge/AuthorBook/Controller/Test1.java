package com.capge.AuthorBook.Controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.capge.AuthorBook.Entity.Book;

public class Test1 {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JpaAssign2");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		
		
		
		Book b1=new Book(700,"Diksha","321A","	Harry Potter",600);
		Book b2=new Book(800,"Sriya","456T","Princess",800);
		Book b3=new Book(900,"Shubham","E5TO","Vampire",1400);
		Book b4=new Book(1000,"Shubhi","R78","Rapenzel",1600);
		
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		
	
		
		//entityManager.persist(a1);
		//entityManager.persist(a2);
		entityManager.persist(b1);
		entityManager.persist(b2);
		entityManager.persist(b3);
		entityManager.persist(b4);
		
		
		entityTransaction.commit();
		
		
		System.out.println( "Diksha");
		System.out.println("Objects saved into table.!");
		entityManager.close();
		
		

	}

}
