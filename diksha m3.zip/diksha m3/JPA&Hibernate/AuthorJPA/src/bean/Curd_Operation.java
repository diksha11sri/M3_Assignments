package bean;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class Curd_Operation {
	static EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("Author");
	 static EntityManager entitymanager=emfactory.createEntityManager();
	  
		public static void main(String[] args) {
		     Curd_Operation co=new Curd_Operation();
         System.out.println("Diksha");
            author a=new author();
			a.setAuthorid(102);
			a.setFirstName("Aman");
			a.setMiddleName("Kumar");
			a.setLastName("Singh");
			a.setPhoneNo(123456789);
			co.InsertIntoAuthorDB(a);

			//  co.DeleteAuthor(101);
		  //    System.out.println("records deleted");
		}
		public void InsertIntoAuthorDB(author a)
		{
		entitymanager.getTransaction().begin();
		entitymanager.persist(a);
		entitymanager.getTransaction().commit();
		}
	//	public void DeleteAuthor(int id)
		//{
	//		entitymanager.getTransaction().begin();
	//		author au=entitymanager.find(author.class, id);
		//	entitymanager.remove(au);
	//		entitymanager.getTransaction().commit();
	//	}
		     // co.UpdateAuthor(101,2345678);
			//co.getauthorDetails(101);
		    // System.out.println("author id"+a.getAuthorid());
		   //  System.out.println("author first name"+a.getFirstName());
		   //  System.out.println("author middle name"+a.getMiddleName());
		    // System.out.println("author last name"+a.getLastName());
		    // System.out.println("author phone number"+a.getPhoneNo());

		
		
				
		   
			
		     /*  
			
			 public void UpdateAuthor(int id,int phoneNo)
			  {
				  entitymanager.getTransaction().begin();
				  author au=entitymanager.find(author.class, id);
				  au.setPhoneNo(phoneNo);
				  entitymanager.getTransaction().commit();
			  }
			*/
			/*public void InsertIntoEmployeeDB(Employee emp)
			{
			entitymanager.getTransaction().begin();
			entitymanager.persist(emp);
			entitymanager.getTransaction().commit();
			}
			public author getauthorDetails(int id) 
		{
			author au =entitymanager.find(author.class, id);
			return au;
		}
			
		
			
		/*	
			
				
	    	*/
			
}
